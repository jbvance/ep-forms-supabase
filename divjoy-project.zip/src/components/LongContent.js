import React from "react";

function LongContent(props) {
  return <div className="LongContent">{props.children}</div>;
}

export default LongContent;
